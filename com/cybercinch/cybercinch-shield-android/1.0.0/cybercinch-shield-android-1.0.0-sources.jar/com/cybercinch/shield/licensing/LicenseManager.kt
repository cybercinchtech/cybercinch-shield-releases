package com.cybercinch.shield.licensing

import android.util.Log
import com.cybercinch.shield.network.SslPinningManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

internal object LicenseManager {

    private const val VALIDATE_PATH = "/v1/license/validate"
    private const val PLATFORM      = "android"
    private const val LOG_TAG       = "CyberCinch"
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    data class LicenseFeatures(
        val runtimeProtection: Boolean,
        val sslPinning:        Boolean,
        val telemetry:         Boolean,
        val configUpdates:     Boolean
    )

    data class LicenseResponse(
        val valid:            Boolean,
        val plan:             String,
        val features:         LicenseFeatures,
        val configVersion:    Int,
        val sessionToken:     String,
        val sessionExpiresAt: Long
    )

    private sealed class LicenseResult {
        data class Success(val response: LicenseResponse) : LicenseResult()
        object InvalidApiKey   : LicenseResult()
        object PackageMismatch : LicenseResult()
        data class NetworkError(val message: String) : LicenseResult()
    }

    /**
     * Calls /v1/license/validate and returns the server's [LicenseResponse], or null when
     * [failOpen] is true and the server cannot be reached / returns an error.
     *
     * @throws IllegalStateException if [failOpen] is false and validation fails.
     */
    suspend fun validate(
        apiKey:      String,
        baseUrl:     String,
        packageName: String,
        sdkVersion:  String,
        failOpen:    Boolean
    ): LicenseResponse? = withContext(Dispatchers.IO) {
        val url = baseUrl.trimEnd('/') + VALIDATE_PATH
        val bodyJson = JSONObject().apply {
            put("api_key",      apiKey)
            put("package_name", packageName)
            put("platform",     PLATFORM)
            put("sdk_version",  sdkVersion)
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyJson.toRequestBody(JSON_TYPE))
            .build()

        val client = SslPinningManager.buildSdkClient()
            .newBuilder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build()

        // Retry policy per API_CONTRACT.md: /v1/license/validate — 3 retries, 1s/2s/4s backoff.
        var lastResult: LicenseResult = LicenseResult.NetworkError("No attempt made")
        val backoffMs = longArrayOf(1_000, 2_000, 4_000)
        loop@ for (attempt in 0..2) {
            lastResult = try {
                client.newCall(request).execute().use { response ->
                    when (response.code) {
                        200  -> parseSuccess(response.body?.string() ?: "")
                        401  -> LicenseResult.InvalidApiKey
                        403  -> LicenseResult.PackageMismatch
                        else -> LicenseResult.NetworkError("HTTP ${response.code}")
                    }
                }
            } catch (e: IOException) {
                LicenseResult.NetworkError(e.message ?: "network error")
            }

            when (lastResult) {
                is LicenseResult.Success,
                is LicenseResult.InvalidApiKey,
                is LicenseResult.PackageMismatch -> break@loop
                is LicenseResult.NetworkError    ->
                    if (attempt < 2) kotlinx.coroutines.delay(backoffMs[attempt])
            }
        }

        val r = lastResult
        if (r is LicenseResult.Success) {
            r.response
        } else {
            val msg = when (r) {
                is LicenseResult.InvalidApiKey   -> "invalid API key"
                is LicenseResult.PackageMismatch -> "package name mismatch"
                is LicenseResult.NetworkError    -> r.message
                else                             -> "unexpected result"
            }
            if (failOpen) {
                Log.w(LOG_TAG, "License validation failed ($msg) — proceeding with local config")
                null
            } else {
                throw IllegalStateException("License validation failed: $msg")
            }
        }
    }

    private fun parseSuccess(json: String): LicenseResult {
        return try {
            val root = JSONObject(json)
            if (!root.optBoolean("valid", false)) return LicenseResult.InvalidApiKey

            val feat = root.getJSONObject("features")
            val response = LicenseResponse(
                valid            = true,
                plan             = root.optString("plan"),
                features         = LicenseFeatures(
                    runtimeProtection = feat.optBoolean("runtime_protection"),
                    sslPinning        = feat.optBoolean("ssl_pinning"),
                    telemetry         = feat.optBoolean("telemetry"),
                    configUpdates     = feat.optBoolean("config_updates")
                ),
                configVersion    = root.optInt("config_version"),
                sessionToken     = root.optString("session_token"),
                sessionExpiresAt = root.optLong("session_expires_at")
            )
            LicenseResult.Success(response)
        } catch (e: Exception) {
            LicenseResult.NetworkError("parse error: ${e.message}")
        }
    }
}
