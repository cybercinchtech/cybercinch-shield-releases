package com.cybercinch.shield.telemetry

import android.util.Log
import com.cybercinch.shield.device.DeviceSigningKey
import com.cybercinch.shield.models.SecurityEvent
import com.cybercinch.shield.network.SslPinningManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// Bridges android-sdk to the local EventQueue + TelemetrySerializer.
// Adds request signing and exponential-backoff retry per API_CONTRACT.md:
// /v1/events — 8s timeout, 3 retries, 1s/2s/4s backoff.
//
// TD-037 dual-auth: registeredAPIKeyID is non-null only after
// CyberCinchCore has confirmed a successful POST /v1/devices/register for
// this device. When set, postEvents signs each batch with the device's own
// Keystore key (X-CC-Device-JWS) instead of the attestation-gated
// verdict-token+HMAC scheme. Falling back to the verdict-token path when
// it's null (registration hasn't succeeded yet, or failed) is the
// dual-auth transition working exactly as designed — not an error case.
internal class TelemetryDispatcher(
    private val apiKey:             String,
    private val deviceId:           String,
    private val packageName:        String,
    private val deviceKey:          ByteArray,
    private val verdictToken:       String,
    private val baseUrl:            String,
    private val registeredAPIKeyID: String? = null
) {
    private val scope      = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val serializer = TelemetrySerializer()
    private val client     = SslPinningManager.buildSdkClient()
    private val random     = SecureRandom()
    private val JSON_TYPE  = "application/json; charset=utf-8".toMediaType()

    // Backoff delays per API_CONTRACT.md retry table for /v1/events.
    private val BACKOFF_MS = longArrayOf(1_000, 2_000, 4_000)

    // Events from a failed dispatch are held here and prepended to the next batch.
    private val retryBuffer = ConcurrentLinkedQueue<SecurityEvent>()

    private val queue = EventQueue(
        onFlush = { events -> postEvents(events) },
        scope   = scope
    )

    fun enqueue(event: SecurityEvent) {
        scope.launch { queue.enqueue(event) }
    }

    // Triggers an immediate flush of all queued events (including any from retryBuffer).
    // Called directly by CyberCinchCore for AUTO_IMMEDIATE and MANUAL modes,
    // and by the periodic batch coroutine for AUTO_BATCHED mode.
    fun dispatch() {
        scope.launch { queue.flush() }
    }

    // Serializes, signs, and POSTs one flush batch to {baseUrl}/v1/events.
    // On any failure the batch is preserved in retryBuffer and merged into the next call.
    private suspend fun postEvents(freshEvents: List<SecurityEvent>) {
        // Drain previously-failed events and prepend them to this batch.
        val retried = mutableListOf<SecurityEvent>()
        while (true) retried += retryBuffer.poll() ?: break
        val events = retried + freshEvents
        if (events.isEmpty()) return

        val body      = serializer.serialize(deviceId, events)
        val timestamp = (System.currentTimeMillis() / 1_000L).toString()
        val nonce     = generateNonce()

        val requestBuilder = Request.Builder()
            .url("$baseUrl/v1/events")
            .addHeader("Authorization",  "Bearer $apiKey")
            .addHeader("X-CC-Timestamp", timestamp)
            .addHeader("X-CC-Nonce",     nonce)

        // TD-037 dual-auth: prefer the device JWS path once registration has
        // succeeded (registeredAPIKeyID non-null); DeviceSigningKey.signJWS
        // itself also returns null if the Keystore key is somehow missing,
        // so this falls through to the verdict-token path on either
        // condition — never a hard failure.
        val deviceJWS = registeredAPIKeyID?.let { apiKeyId ->
            DeviceSigningKey.signJWS(
                apiKeyId = apiKeyId,
                deviceId = deviceId,
                pkg      = packageName,
                nonce    = nonce,
                bodyHash = sha256Hex(body)
            )
        }

        if (deviceJWS != null) {
            requestBuilder.addHeader("X-CC-Device-JWS", deviceJWS)
        } else {
            // Signature: v1=hex(HMAC-SHA256(device_key, timestamp || nonce || body))
            // Matches ValidateEventSignature in backend/telemetry-service/pkg/crypto/hmac.go.
            val signature = "v1=${hmacSha256(deviceKey, timestamp + nonce + body)}"
            requestBuilder
                .addHeader("X-CC-Signature",     signature)
                .addHeader("X-CC-Verdict-Token", verdictToken)
        }

        val request = requestBuilder.post(body.toRequestBody(JSON_TYPE)).build()

        for (attempt in 0..2) {
            try {
                client.newCall(request).execute().use { response ->
                    if (response.code == 429) {
                        val retryAfter = response.header("Retry-After")?.toLongOrNull() ?: 60L
                        Log.w(TAG, "rate-limited by server; ${events.size} events queued for retry after ${retryAfter}s")
                        delay(retryAfter * 1_000L)
                        events.forEach(retryBuffer::offer)
                        return
                    }
                    if (response.isSuccessful) return  // success — EventQueue already cleared the batch
                    Log.w(TAG, "attempt ${attempt + 1}/3: server returned HTTP ${response.code}: ${response.body?.string()?.take(300)}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "attempt ${attempt + 1}/3 failed [${e.javaClass.simpleName}]: ${e.message}")
            }

            if (attempt < 2) delay(BACKOFF_MS[attempt])
        }

        // All 3 attempts failed — preserve events so the next dispatch picks them up.
        Log.w(TAG, "dispatch failed after 3 attempts; ${events.size} events queued for retry")
        events.forEach(retryBuffer::offer)
    }

    // hex(SHA-256(body)) — must match telemetry-service's verifyDeviceJWS
    // exactly: bodyHash := sha256.Sum256(body); hex.EncodeToString(bodyHash[:]).
    private fun sha256Hex(body: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(body.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun hmacSha256(key: ByteArray, message: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(message.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun generateNonce(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private companion object {
        private const val TAG = "TelemetryDispatcher"
    }
}
