package com.cybercinch.shield.network

import okhttp3.CertificatePinner
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import okhttp3.TlsVersion
import java.util.concurrent.TimeUnit

internal object SslPinningManager {

    private const val SDK_API_HOST = "api.cybercinch.in"

    // Intermediate CA pins for api.cybercinch.in.
    // TODO: replace placeholders with real SHA-256 SPKI hashes before release.
    // Backup pin must differ from primary to satisfy RFC 7469 §2.5.3.
    private val SDK_PINS = arrayOf(
        "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",   // primary
        "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB="    // backup
    )

    // TLS 1.3-only. Older versions are not negotiated per API_CONTRACT.md.
    private val TLS13_SPEC = ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
        .tlsVersions(TlsVersion.TLS_1_3)
        .build()

    // OkHttpClient for all SDK-internal calls to api.cybercinch.in.
    // Extra pins are appended (supports pin rotation from OTA config).
    fun buildSdkClient(extraPins: Array<out String> = emptyArray()): OkHttpClient {
        val pinner = CertificatePinner.Builder()
        SDK_PINS.forEach { pinner.add(SDK_API_HOST, it) }
        extraPins.forEach  { pinner.add(SDK_API_HOST, "sha256/$it") }

        return OkHttpClient.Builder()
            .certificatePinner(pinner.build())
            .connectionSpecs(listOf(TLS13_SPEC, ConnectionSpec.CLEARTEXT))
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    // Builds a pinned OkHttpClient for the host app's own backend.
    // hashes are raw base64-encoded SHA-256 SPKI values (no "sha256/" prefix).
    fun buildPinnedClientForHost(hostname: String, vararg hashes: String): OkHttpClient {
        val pinner = CertificatePinner.Builder()
        hashes.forEach { pinner.add(hostname, "sha256/$it") }

        return OkHttpClient.Builder()
            .certificatePinner(pinner.build())
            .connectionSpecs(listOf(TLS13_SPEC, ConnectionSpec.CLEARTEXT))
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    // Returns true when the OTA config contains pin entries, signalling
    // that the caller should rebuild the SDK client with the new pins.
    fun pinsNeedRotation(configPins: List<String>): Boolean = configPins.isNotEmpty()
}
