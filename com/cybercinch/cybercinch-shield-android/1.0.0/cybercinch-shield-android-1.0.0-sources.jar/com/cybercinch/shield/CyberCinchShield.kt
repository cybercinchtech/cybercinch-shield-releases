package com.cybercinch.shield

import android.content.Context
import com.cybercinch.shield.core.CyberCinchCore
import com.cybercinch.shield.models.ScanResult

object CyberCinchShield {

    /**
     * Initialize the SDK. Must be called in Application.onCreate().
     * Performs: license validation, attestation, config fetch.
     * @param context Application context
     * @param apiKey Your CyberCinch API key
     * @param config Optional SDK configuration
     */
    fun initialize(
        context: Context,
        apiKey: String,
        config: ShieldConfig = ShieldConfig()
    ) {
        CyberCinchCore.initialize(context, apiKey, config)
    }

    /**
     * Run a security scan. Returns immediately with local scan result.
     * Server attestation result will be available via onServerVerdict callback.
     */
    suspend fun scan(): ScanResult = CyberCinchCore.scan()

    /**
     * Enable SSL pinning for your app's network calls.
     * Pins the intermediate CA with a backup pin.
     */
    fun enableSslPinning(vararg certificateHashes: String) {
        CyberCinchCore.enableSslPinning(*certificateHashes)
    }

    /**
     * Enable/disable telemetry event submission.
     * Must be called before scan() to take effect.
     */
    fun setTelemetryConsent(enabled: Boolean) {
        CyberCinchCore.setTelemetryConsent(enabled)
    }

    /**
     * Register a callback for server-side attestation verdict.
     * Called asynchronously after scan() — may arrive 1-3 seconds later.
     */
    fun onServerVerdict(callback: (ScanResult) -> Unit) {
        CyberCinchCore.onServerVerdict(callback)
    }

    /**
     * Get the current SDK version string.
     */
    fun sdkVersion(): String = CyberCinchCore.sdkVersion()

    /**
     * Immediately flush all queued telemetry events to the backend.
     * Required in MANUAL mode; also available as an early-flush escape hatch
     * in AUTO_IMMEDIATE and AUTO_BATCHED.
     */
    fun flushTelemetry() {
        CyberCinchCore.flushTelemetry()
    }

    /**
     * Report a client-side error or crash. Emits a CLIENT_ERROR_REPORTED
     * telemetry event (risk_score is always 0 — this is not a security
     * signal) carrying the exception type, message, and a capped stack
     * trace. Dispatched through the same telemetry consent/dispatch-mode
     * settings as scan() events.
     *
     * Safe to call from a catch block or an uncaught-exception handler —
     * this function never throws back into caller code.
     *
     * @param throwable the caught exception or error
     * @param fatal whether this error was fatal to the calling operation
     *   (e.g. an uncaught exception vs. one that was caught and recovered)
     */
    fun reportError(throwable: Throwable, fatal: Boolean = false) {
        CyberCinchCore.reportError(throwable, fatal)
    }
}
