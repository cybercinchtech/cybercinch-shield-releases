package com.cybercinch.shield.telemetry

import com.cybercinch.shield.models.SecurityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private const val DEFAULT_MAX_SIZE = 500
private const val FLUSH_INTERVAL_MS = 30_000L
private const val MAX_EVENT_AGE_MS = 24L * 60 * 60 * 1_000

class EventQueue(
    private val maxSize: Int = DEFAULT_MAX_SIZE,
    private val onFlush: suspend (List<SecurityEvent>) -> Unit,
    scope: CoroutineScope,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val mutex = Mutex()
    private val queue = mutableListOf<TimestampedEvent>()

    private data class TimestampedEvent(
        val event: SecurityEvent,
        val enqueuedAt: Long
    )

    init {
        scope.launch {
            while (true) {
                delay(FLUSH_INTERVAL_MS)
                flush()
            }
        }
    }

    suspend fun enqueue(event: SecurityEvent) {
        val full = mutex.withLock {
            queue.add(TimestampedEvent(event, clock()))
            // maxSize is a flush trigger, not a hard cap — events are never rejected.
            // We add before checking so the maxSize-th event is included in the flush
            // batch. >= rather than == is intentional: concurrent enqueues can push the
            // size past maxSize in separate lock acquisitions, and >= ensures every such
            // coroutine also triggers a flush rather than silently skipping it.
            queue.size >= maxSize
        }
        if (full) flush()
    }

    suspend fun flush() {
        val toFlush = mutex.withLock {
            val cutoff = clock() - MAX_EVENT_AGE_MS
            val fresh = queue.filter { it.enqueuedAt >= cutoff }.map { it.event }
            queue.clear()
            fresh
        }
        if (toFlush.isNotEmpty()) {
            onFlush(toFlush)
        }
    }
}
