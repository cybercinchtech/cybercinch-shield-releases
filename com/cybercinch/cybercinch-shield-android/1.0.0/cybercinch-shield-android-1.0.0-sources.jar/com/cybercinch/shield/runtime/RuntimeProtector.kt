package com.cybercinch.shield.runtime

import com.cybercinch.shield.models.ModuleResult
import com.cybercinch.shield.models.SecurityEvent
import com.cybercinch.shield.models.SecurityEventType
import java.util.UUID

class RuntimeProtector {

    // frida_detector.cpp: [frida_port(0/1), frida_maps(0/1), debugger(0/1), xposed(0/1), got_plt_anomaly(0/1), inline_hook_prologue(0/1), xposed_stack_artifact(0/1), java_native_bait_mismatch(0/1)]
    private external fun nativeCheckRuntime(): IntArray

    // anti_debug.cpp: [tracerPid(0/1), timingAnomaly(0/1), detectedAtLoad(0/1)]
    private external fun nativeAntiDebugCheck(): IntArray

    // frida_detector.cpp: 1 if libhoudini or libndk_translation found in /proc/self/maps
    internal external fun nativeCheckTranslationMaps(): Int

    fun detect(): ModuleResult {
        val startMs  = System.currentTimeMillis()
        val runtime  = nativeCheckRuntime()
        val antidebug = nativeAntiDebugCheck()
        val now = System.currentTimeMillis()

        val events = buildList {
            if (runtime[0] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.FRIDA_DETECTED,
                riskContribution = 80,
                detectedAt       = now,
                metadata         = mapOf("signal" to "frida_port")
            ))
            if (runtime[1] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.FRIDA_DETECTED,
                riskContribution = 80,
                detectedAt       = now,
                metadata         = mapOf("signal" to "frida_maps_or_phdr")
            ))
            if (runtime[2] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.DEBUGGER_ATTACHED,
                riskContribution = 75,
                detectedAt       = now,
                metadata         = mapOf("signal" to "ptrace_or_tracer_pid")
            ))
            if (runtime[3] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.HOOK_FRAMEWORK_DETECTED,
                riskContribution = 70,
                detectedAt       = now,
                metadata         = mapOf("signal" to "xposed_lsposed")
            ))
            if (runtime[4] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.FRIDA_DETECTED,
                riskContribution = 85,
                detectedAt       = now,
                metadata         = mapOf("signal" to "got_plt_anomaly")
            ))
            if (runtime[5] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.HOOK_FRAMEWORK_DETECTED,
                riskContribution = 75,
                detectedAt       = now,
                metadata         = mapOf("signal" to "inline_hook_prologue")
            ))
            if (runtime[6] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.HOOK_FRAMEWORK_DETECTED,
                riskContribution = 80,
                detectedAt       = now,
                metadata         = mapOf("signal" to "xposed_stack_trace_artifact")
            ))
            // TD-031: eventType HOOK_FRAMEWORK_DETECTED, not a new SecurityEventType —
            // BypassRootCheckPro is itself an LSPosed module, same family as the
            // xposed_lsposed/xposed_stack_trace_artifact signals above, just caught via a
            // different evidence type. A dedicated type was considered and rejected: it
            // would ripple into shared-kmp and the dashboard's enum consumers, well past
            // this task's scope, and the metadata `signal` key already lets consumers
            // distinguish this finding without a schema change. riskContribution = 80,
            // matching xposed_stack_trace_artifact (TD-029) — both are confirmed real hook
            // activity via indirect/behavioral evidence, verified on device (ISSUE-018).
            if (runtime[7] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.HOOK_FRAMEWORK_DETECTED,
                riskContribution = 80,
                detectedAt       = now,
                metadata         = mapOf("signal" to "java_native_bait_mismatch")
            ))
            // Anti-debug constructor trap or timing anomaly counts as DEBUGGER_ATTACHED
            if (antidebug[0] != 0 || antidebug[1] != 0 || antidebug[2] != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.DEBUGGER_ATTACHED,
                riskContribution = 75,
                detectedAt       = now,
                metadata         = mapOf("signal" to "antidebug_tracer_or_timing")
            ))
        }

        // DELIBERATE BEHAVIOR CHANGE (TD-021): HOOK_FRAMEWORK_DETECTED now
        // independently gates `compromised`. This also affects the existing
        // xposed_lsposed signal (runtime[3]) — it will now set
        // Runtime Compromised: true on its own, which it did NOT do before
        // this change (it previously only contributed risk score).
        val compromised = events.any {
            it.eventType == SecurityEventType.FRIDA_DETECTED ||
            it.eventType == SecurityEventType.DEBUGGER_ATTACHED ||
            it.eventType == SecurityEventType.HOOK_FRAMEWORK_DETECTED
        }

        return ModuleResult(
            moduleName       = MODULE_NAME,
            passed           = !compromised,
            riskContribution = events.sumOf { it.riskContribution }.coerceAtMost(100),
            events           = events,
            durationMs       = System.currentTimeMillis() - startMs
        )
    }

    companion object {
        private const val MODULE_NAME = "RuntimeProtector"

        // Called by EmulatorDetector.kt to check libhoudini/libndk_translation maps.
        // Implementation lives in frida_detector.cpp for scan_maps() reuse.
        fun checkTranslationMaps(): Int = RuntimeProtector().nativeCheckTranslationMaps()

        init { System.loadLibrary("cybercinch_shield") }
    }
}
