package com.cybercinch.shield.core

import android.content.Context
import android.util.Log
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.cybercinch.shield.ShieldConfig
import com.cybercinch.shield.TelemetryMode
import com.cybercinch.shield.attestation.AttestationFailedException
import com.cybercinch.shield.attestation.PlayIntegrityManager
import com.cybercinch.shield.device.DeviceRegistrar
import com.cybercinch.shield.device.DeviceSigningKey
import com.cybercinch.shield.emulator.EmulatorDetector
import com.cybercinch.shield.integrity.IntegrityChecker
import com.cybercinch.shield.attestation.LocalScanSnapshot
import com.cybercinch.shield.licensing.LicenseManager
import com.cybercinch.shield.models.ModuleResult
import com.cybercinch.shield.models.ScanResult
import com.cybercinch.shield.models.SecurityEvent
import com.cybercinch.shield.models.SecurityEventType
import com.cybercinch.shield.risk.RiskEngine
import com.cybercinch.shield.root.RootDetector
import com.cybercinch.shield.runtime.RuntimeProtector
import com.cybercinch.shield.telemetry.TelemetryDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal object CyberCinchCore {

    const val SDK_VERSION = "1.0.0"

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "cc_shield_v1"
    private const val API_KEY_FILE = "cc_ak.enc"
    private const val SESSION_FILE = "cc_st.enc"
    // Stores the api_key_id (UUID) this device successfully registered
    // under (TD-037 PART 4) — its mere existence/decryptability is the
    // local "registration succeeded" flag; presence gates whether
    // TelemetryDispatcher takes the device-JWS path or falls back to the
    // verdict-token path.
    private const val DEVICE_REGISTERED_FILE = "cc_dev_reg.enc"
    private const val GCM_IV_SIZE = 12
    private const val GCM_TAG_SIZE = 128
    private const val TAG = "CyberCinchCore"

    // POST /v1/events caps the whole batch body at 2 MiB (telemetry_handler.go)
    // shared across every event in the batch — an uncapped stack trace could
    // crowd out other events. 4 KB per trace leaves ample headroom (a batch
    // would need 500+ maxed-out traces before approaching the body cap).
    private const val MAX_STACK_TRACE_CHARS = 4096

    // ---------------------------------------------------------------------------
    // State machine
    // ---------------------------------------------------------------------------

    private enum class State { UNINITIALIZED, INITIALIZING, READY, FAILED }

    private val state = AtomicReference(State.UNINITIALIZED)

    // ---------------------------------------------------------------------------
    // Feature flags received from the license response
    // ---------------------------------------------------------------------------

    private data class FeatureFlags(
        val runtimeProtection: Boolean = false,
        val sslPinning: Boolean = false,
        val telemetry: Boolean = false,
        val configUpdates: Boolean = false
    )

    // ---------------------------------------------------------------------------
    // Runtime state (written once during init, read thereafter)
    // ---------------------------------------------------------------------------

    @Volatile private var applicationContext: Context? = null
    @Volatile private var config: ShieldConfig = ShieldConfig()
    @Volatile private var features: FeatureFlags? = null

    // ---------------------------------------------------------------------------
    // Mutable state (may be updated after init)
    // ---------------------------------------------------------------------------

    @Volatile private var telemetryEnabled: Boolean = true
    @Volatile private var serverVerdictCallback: ((ScanResult) -> Unit)? = null
    @Volatile private var pinnedHashes: Array<out String> = emptyArray()
    @Volatile private var dispatcher: TelemetryDispatcher? = null

    // Captured from PlayIntegrityManager's AttestationFailedException
    // (TD-037 PART 4) — available for forwarding on outgoing events, but
    // not yet wired into any event's metadata (that's PART 5's full
    // event-schema wiring, deliberately separate from this pass).
    @Volatile internal var lastAttestationStatus: String? = null
    @Volatile internal var lastAttestationReason: String? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---------------------------------------------------------------------------
    // Foreground-resume scan trigger
    // ProcessLifecycleOwner.onStart() fires once per genuine whole-app
    // background→foreground transition — already debounced against internal
    // Activity-to-Activity navigation and configuration changes (rotation), unlike
    // Application.ActivityLifecycleCallbacks' per-Activity onActivityResumed().
    // Registered once from initialize(); never re-registered (initialize() itself
    // is one-shot per the state machine below).
    // ---------------------------------------------------------------------------

    private val foregroundObserver = object : DefaultLifecycleObserver {
        override fun onStart(owner: LifecycleOwner) {
            scope.launch {
                if (state.get() != State.READY) {
                    Log.d(TAG, "foreground-resume: app returned to foreground but SDK not READY yet (state=${state.get()}) — skipping automatic scan")
                    return@launch
                }
                try {
                    Log.d(TAG, "foreground-resume: app returned to foreground — running automatic scan")
                    scan()
                } catch (e: Exception) {
                    Log.w(TAG, "foreground-resume: automatic scan failed [${e.javaClass.simpleName}]: ${e.message}")
                }
            }
        }
    }

    // ---------------------------------------------------------------------------
    // App-process-start auto-first-scan
    // Set once by CyberCinchInitProvider.onCreate() (installed automatically at
    // process start via the SDK's own merged manifest — no integrator code needed).
    // Does NOT call initialize() itself and does NOT drive the state machine —
    // initialize() remains the sole, mandatory, API-key-bearing entry point. This
    // only arms a one-shot "run a scan automatically the moment READY is reached"
    // behavior, whenever/wherever the integrator's own initialize() call gets there.
    // ---------------------------------------------------------------------------

    @Volatile private var autoFirstScanEnabled: Boolean = false

    internal fun enableAutoFirstScan() {
        autoFirstScanEnabled = true
    }

    // ---------------------------------------------------------------------------
    // Public interface (called by CyberCinchShield)
    // ---------------------------------------------------------------------------

    // A second call is a safe no-op, not a crash: ordinary Android lifecycle behavior
    // (e.g. an Activity recreated on rotation re-running onCreate()) makes a repeat
    // initialize() call from Activity-level integration code entirely realistic, not
    // just a caller error. The guard below is a hard gate BEFORE any side effect —
    // re-running the body on a second call would duplicate the AUTO_BATCHED dispatch
    // timer forever, orphan events queued in the discarded TelemetryDispatcher, and
    // burn a second one-time-use attestation nonce for no benefit. First call wins:
    // a second call's apiKey/config are intentionally discarded, matching
    // FirebaseApp.initializeApp()'s own "first call wins" convention.
    fun initialize(context: Context, apiKey: String, config: ShieldConfig) {
        if (!state.compareAndSet(State.UNINITIALIZED, State.INITIALIZING)) {
            Log.w(TAG, "CyberCinchShield.initialize() called more than once — ignoring, SDK keeps using its first initialize() call's configuration")
            return
        }
        val appContext = context.applicationContext
        applicationContext = appContext
        this.config = config
        telemetryEnabled = config.enableTelemetry

        ProcessLifecycleOwner.get().lifecycle.addObserver(foregroundObserver)

        scope.launch {
            try {
                val localScan = runLocalScanForAttestPreflight(appContext)

                storeApiKey(appContext, apiKey)

                val license = LicenseManager.validate(
                    apiKey      = apiKey,
                    baseUrl     = config.licenseBaseUrl,
                    packageName = appContext.packageName,
                    sdkVersion  = SDK_VERSION,
                    failOpen    = config.licenseValidationFailOpen
                )

                val deviceId = Settings.Secure.getString(
                    appContext.contentResolver, Settings.Secure.ANDROID_ID
                ) ?: "unknown"

                var verdictToken = ""
                var attestedDeviceKey: ByteArray? = null

                // TD-037 PART 4: local record of a prior successful
                // POST /v1/devices/register, if any. Its presence (not the
                // Keystore key's mere existence — the server must have
                // actually accepted it) is what lets TelemetryDispatcher use
                // the device-JWS path instead of the verdict-token path.
                var registeredAPIKeyID = decryptFromFile(appContext, DEVICE_REGISTERED_FILE)

                if (license != null) {
                    features = FeatureFlags(
                        runtimeProtection = license.features.runtimeProtection,
                        sslPinning        = license.features.sslPinning,
                        telemetry         = license.features.telemetry,
                        configUpdates     = license.features.configUpdates
                    )
                    storeSessionToken(appContext, license.sessionToken)

                    if (registeredAPIKeyID == null) {
                        // Never blocks initialize() on failure — a failed
                        // registration attempt just means the dispatcher below
                        // falls back to the verdict-token path, exactly the
                        // dual-auth transition working as designed. Retried
                        // naturally on the next app launch, since only a
                        // genuine success writes DEVICE_REGISTERED_FILE.
                        try {
                            DeviceSigningKey.ensureKeyPair()
                            val publicKeyB64 = DeviceSigningKey.publicKeyBase64()
                            val apiKeyIdFromSession = decodeJWTClaim(license.sessionToken, "sub")
                            if (publicKeyB64 != null && apiKeyIdFromSession != null) {
                                val registered = DeviceRegistrar.register(
                                    apiKey          = apiKey,
                                    deviceId        = deviceId,
                                    packageName     = appContext.packageName,
                                    platform        = "android",
                                    publicKeyBase64 = publicKeyB64,
                                    baseUrl         = config.licenseBaseUrl
                                )
                                if (registered) {
                                    encryptToFile(appContext, apiKeyIdFromSession, DEVICE_REGISTERED_FILE)
                                    registeredAPIKeyID = apiKeyIdFromSession
                                    Log.d(TAG, "device registration: succeeded")
                                } else {
                                    Log.w(TAG, "device registration: server did not accept — falling back to verdict-token path")
                                }
                            } else {
                                Log.w(TAG, "device registration: missing public key or api_key_id — falling back to verdict-token path")
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "device registration: [${e.javaClass.simpleName}]: ${e.message} — falling back to verdict-token path")
                        }
                    }

                    try {
                        val attestResult = PlayIntegrityManager.attest(
                            context      = appContext,
                            sessionToken = license.sessionToken,
                            deviceId     = deviceId,
                            baseUrl      = config.attestationBaseUrl,
                            localScan    = localScan
                        )
                        verdictToken      = attestResult.verdictToken
                        attestedDeviceKey = attestResult.deviceKey
                        lastAttestationStatus = null
                        lastAttestationReason = null
                        Log.d(TAG, "attestation: completed, real device key obtained")
                    } catch (e: AttestationFailedException) {
                        lastAttestationStatus = e.status
                        lastAttestationReason = e.reason
                        Log.w(TAG, "attestation: ${e.status} (${e.reason}) — telemetry will use placeholder key")
                        verdictToken = license.sessionToken
                    } catch (e: Exception) {
                        Log.w(TAG, "attestation: [${e.javaClass.simpleName}]: ${e.message} — telemetry will use placeholder key")
                        verdictToken = license.sessionToken
                    }
                }
                // license == null: fail-open, no session token available for attestation,
                // verdictToken stays empty and deriveDeviceKey() provides the placeholder.

                if (config.enableTelemetry) {
                    val resolvedDeviceKey = attestedDeviceKey ?: run {
                        Log.w(TAG, "telemetry: attestation did not complete — using placeholder device key, HMAC will not validate server-side")
                        deriveDeviceKey(apiKey)
                    }
                    dispatcher = TelemetryDispatcher(
                        apiKey             = apiKey,
                        deviceId           = deviceId,
                        packageName        = appContext.packageName,
                        deviceKey          = resolvedDeviceKey,
                        verdictToken       = verdictToken,
                        baseUrl            = config.telemetryBaseUrl,
                        registeredAPIKeyID = registeredAPIKeyID
                    )
                    when (config.telemetryMode) {
                        TelemetryMode.AUTO_IMMEDIATE ->
                            Log.d(TAG, "telemetry: dispatcher ready, mode=AUTO_IMMEDIATE")
                        TelemetryMode.AUTO_BATCHED -> {
                            Log.d(TAG, "telemetry: AUTO_BATCHED timer started, interval=${config.telemetryBatchIntervalMs}ms")
                            scope.launch {
                                while (true) {
                                    delay(config.telemetryBatchIntervalMs)
                                    Log.d(TAG, "telemetry: AUTO_BATCHED timer fired — flushing queued events")
                                    dispatcher?.dispatch()
                                }
                            }
                        }
                        TelemetryMode.MANUAL ->
                            Log.d(TAG, "telemetry: dispatcher ready, mode=MANUAL — call flushTelemetry() to send events")
                    }
                } else {
                    Log.d(TAG, "telemetry: disabled (enableTelemetry=false) — no dispatcher created, no events will be sent")
                }

                Log.d(TAG, "CyberCinchCore ready")
                state.set(State.READY)

                if (autoFirstScanEnabled) {
                    try {
                        Log.d(TAG, "process-start: SDK reached READY — running automatic first scan")
                        scan()
                    } catch (e: Exception) {
                        Log.w(TAG, "process-start: automatic first scan failed [${e.javaClass.simpleName}]: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                state.set(State.FAILED)
            }
        }
    }

    // Shared by scan() and the init-time attestation pre-flight (runLocalScanForAttestPreflight)
    // so both call sites run the exact same detector suite under the exact same config gating.
    private fun runDetectorModules(ctx: Context, runtimeProtection: Boolean): List<ModuleResult> =
        buildList {
            if (config.enableEmulatorDetection)
                add(EmulatorDetector().detect(ctx))
            if (config.enableRootDetection && runtimeProtection)
                add(RootDetector().detect())
            if (config.enableRuntimeProtection && runtimeProtection)
                add(RuntimeProtector().detect())
            if (config.enableIntegrityCheck)
                add(IntegrityChecker().detect(ctx))
        }

    // Init-time attestation pre-flight (TD-028): runs the same local detectors scan() uses,
    // before PlayIntegrityManager.attest() is called, so the /v1/attest request's local_scan
    // field carries a real snapshot instead of postAttest()'s old hardcoded placeholder.
    // This is NOT a repeating scan trigger — it runs exactly once, here, during initialize()'s
    // one-shot coroutine. `features` is never set yet at this point (license validation hasn't
    // run), so runtimeProtection uses the same fail-open default `scan()` falls back to.
    // On any failure, falls back to the placeholder values postAttest() used to hardcode —
    // this can only match or improve on prior behavior, never make init worse or block it.
    private fun runLocalScanForAttestPreflight(ctx: Context): LocalScanSnapshot {
        return try {
            val modules = runDetectorModules(ctx, runtimeProtection = true)
            val (score, _) = RiskEngine().aggregate(modules)
            LocalScanSnapshot(
                rooted             = modules.any { it.moduleName == "RootDetector"    && !it.passed },
                emulator           = modules.any { it.moduleName == "EmulatorDetector" && !it.passed },
                runtimeCompromised = modules.any { it.moduleName == "RuntimeProtector" && !it.passed },
                appTampered        = modules.any { it.moduleName == "IntegrityChecker" && !it.passed },
                riskScore          = score
            )
        } catch (e: Exception) {
            Log.w(TAG, "attestation pre-flight: local detection failed [${e.javaClass.simpleName}]: ${e.message} — local_scan will report placeholder values")
            LocalScanSnapshot(rooted = false, emulator = false, runtimeCompromised = false, appTampered = false, riskScore = 0)
        }
    }

    suspend fun scan(): ScanResult {
        check(state.get() == State.READY) {
            "CyberCinchShield is not ready — call initialize() first and wait for it to complete"
        }
        val ctx = checkNotNull(applicationContext)

        // When features is non-null the server granted runtime_protection; use that as the
        // gate for native detectors. When null (fail-open / no server response) fall back
        // to the ShieldConfig flags so local-only scanning still works.
        val runtimeProtection = features?.runtimeProtection ?: true

        val modules = runDetectorModules(ctx, runtimeProtection)

        val (score, level) = RiskEngine().aggregate(modules)

        val result = ScanResult(
            rooted             = modules.any { it.moduleName == "RootDetector"    && !it.passed },
            jailbroken         = false,
            emulator           = modules.any { it.moduleName == "EmulatorDetector" && !it.passed },
            runtimeCompromised = modules.any { it.moduleName == "RuntimeProtector" && !it.passed },
            appTampered        = modules.any { it.moduleName == "IntegrityChecker" && !it.passed },
            riskScore          = score,
            riskLevel          = level,
            events             = modules.flatMap { it.events },
            serverVerified     = (features != null),
            scanTimestamp      = System.currentTimeMillis()
        )

        dispatchEvents(result.events, "scan")

        return result
    }

    // Shared by scan() and reportError() so both respect the same telemetry
    // consent flag, dispatcher-null guard, and telemetryMode dispatch timing.
    private fun dispatchEvents(events: List<SecurityEvent>, source: String) {
        if (!telemetryEnabled) {
            Log.d(TAG, "telemetry: skipped ($source) — enableTelemetry=false or consent not given")
            return
        }
        val d = dispatcher
        if (d == null) {
            Log.w(TAG, "telemetry: enableTelemetry=true but dispatcher is null ($source, init race?)")
            return
        }
        events.forEach(d::enqueue)
        when (config.telemetryMode) {
            TelemetryMode.AUTO_IMMEDIATE -> {
                Log.d(TAG, "telemetry: dispatching ${events.size} event(s) immediately (AUTO_IMMEDIATE, $source)")
                d.dispatch()
            }
            TelemetryMode.AUTO_BATCHED ->
                Log.d(TAG, "telemetry: queued ${events.size} event(s), mode=AUTO_BATCHED ($source), batch fires in ≤${config.telemetryBatchIntervalMs}ms")
            TelemetryMode.MANUAL ->
                Log.d(TAG, "telemetry: queued ${events.size} event(s), mode=MANUAL ($source), awaiting explicit flush")
        }
    }

    // Reports a client-side error/crash as a CLIENT_ERROR_REPORTED telemetry
    // event, reusing the existing /v1/events POST path — no backend schema
    // change needed (event_type is an unvalidated free-form string end-to-end).
    // riskContribution is always 0 — see SecurityEventType.CLIENT_ERROR_REPORTED's
    // doc comment for why that must not change.
    //
    // This function must never throw back into caller code: it is meant to be
    // called from a catch block or an uncaught-exception path, and an
    // exception escaping the error-reporting path itself would be worse than
    // silently dropping the report.
    fun reportError(throwable: Throwable, fatal: Boolean) {
        try {
            val rawTrace = Log.getStackTraceString(throwable)
            val stackTrace = if (rawTrace.length > MAX_STACK_TRACE_CHARS) {
                rawTrace.substring(0, MAX_STACK_TRACE_CHARS)
            } else {
                rawTrace
            }
            val event = SecurityEvent(
                eventId = UUID.randomUUID().toString(),
                eventType = SecurityEventType.CLIENT_ERROR_REPORTED,
                riskContribution = 0,
                detectedAt = System.currentTimeMillis(),
                metadata = mapOf(
                    "error_type" to throwable.javaClass.name,
                    "error_message" to (throwable.message ?: ""),
                    "fatal" to fatal.toString(),
                    "sdk_version" to SDK_VERSION,
                    "stack_trace" to stackTrace
                )
            )
            dispatchEvents(listOf(event), "reportError")
        } catch (e: Exception) {
            Log.w(TAG, "reportError: failed to report client error [${e.javaClass.simpleName}]: ${e.message}")
        }
    }

    fun enableSslPinning(vararg certificateHashes: String) {
        pinnedHashes = certificateHashes
    }

    fun setTelemetryConsent(enabled: Boolean) {
        telemetryEnabled = enabled
    }

    fun onServerVerdict(callback: (ScanResult) -> Unit) {
        serverVerdictCallback = callback
    }

    fun sdkVersion(): String = SDK_VERSION

    // Immediately flushes all queued telemetry events to the backend.
    // This is the only way to trigger dispatch in MANUAL mode, and can also be
    // called at any time in AUTO_IMMEDIATE or AUTO_BATCHED to force an early flush.
    fun flushTelemetry() {
        val d = dispatcher
        if (d != null) {
            Log.d(TAG, "telemetry: flushTelemetry() called — dispatching queued events now")
            d.dispatch()
        } else {
            Log.d(TAG, "telemetry: flushTelemetry() called but no dispatcher (enableTelemetry=false?)")
        }
    }

    // ---------------------------------------------------------------------------
    // Keystore-backed secure storage
    // API key and session token are encrypted with an AES-256-GCM key that never
    // leaves the Android Keystore hardware. The ciphertext is written to the app's
    // private files directory (never to SharedPreferences in plaintext).
    // ---------------------------------------------------------------------------

    // Decodes a claim from a JWT's payload segment WITHOUT verifying the
    // signature (TD-037 PART 4 — needed to read the api_key_id/"sub" claim
    // out of the session token license-service just issued). Safe here
    // specifically because this token was received directly from
    // license-service over TLS in this same request/response — we only need
    // to read a claim license-service itself already vouched for, not
    // re-establish trust in a token from an untrusted source.
    private fun decodeJWTClaim(jwt: String, claim: String): String? {
        return try {
            val parts = jwt.split(".")
            if (parts.size != 3) return null
            val payloadBytes = android.util.Base64.decode(
                parts[1], android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP
            )
            val value = JSONObject(String(payloadBytes, Charsets.UTF_8)).optString(claim, "")
            value.ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }

    // Fallback device key used when attestation fails or is unavailable (e.g. no
    // license response, Play Services absent). Telemetry HMAC will not pass
    // server-side validation with this key — events are dropped by telemetry-service
    // rather than accepted. Replaced by the real HKDF key from AttestResult on success.
    private fun deriveDeviceKey(apiKey: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(apiKey.toByteArray(Charsets.UTF_8))

    private fun storeApiKey(context: Context, apiKey: String) =
        encryptToFile(context, apiKey, API_KEY_FILE)

    @Suppress("unused")
    private fun loadApiKey(context: Context): String? =
        decryptFromFile(context, API_KEY_FILE)

    internal fun storeSessionToken(context: Context, token: String) =
        encryptToFile(context, token, SESSION_FILE)

    internal fun loadSessionToken(context: Context): String? =
        decryptFromFile(context, SESSION_FILE)

    private fun encryptToFile(context: Context, plaintext: String, filename: String) {
        ensureKeystoreKey()
        val key = keystoreKey() ?: error("Android Keystore key unavailable")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv                                          // 12-byte random IV
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        context.filesDir.resolve(filename).writeBytes(iv + ciphertext)
    }

    private fun decryptFromFile(context: Context, filename: String): String? {
        val file = context.filesDir.resolve(filename)
        if (!file.exists()) return null
        val bytes = file.readBytes()
        if (bytes.size <= GCM_IV_SIZE) return null
        val key = keystoreKey() ?: return null
        val iv = bytes.copyOfRange(0, GCM_IV_SIZE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_SIZE, iv))
        return String(cipher.doFinal(bytes, GCM_IV_SIZE, bytes.size - GCM_IV_SIZE), Charsets.UTF_8)
    }

    private fun ensureKeystoreKey() {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        if (ks.containsAlias(KEY_ALIAS)) return
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        keyGen.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        keyGen.generateKey()
    }

    private fun keystoreKey(): SecretKey? {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        return (ks.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.secretKey
    }
}
