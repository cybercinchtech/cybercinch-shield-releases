package com.cybercinch.shield

enum class LogLevel { NONE, DEBUG, VERBOSE }

enum class TelemetryMode { AUTO_IMMEDIATE, AUTO_BATCHED, MANUAL }

data class ShieldConfig(

    /** Enable native root detection. Checks for su binaries, Magisk/Zygisk modules,
     *  and writable system partitions via C++ native code. Gated by the
     *  `runtime_protection` license feature flag when a server response is available;
     *  falls back to this flag when [licenseValidationFailOpen] is true and the
     *  license server is unreachable. */
    val enableRootDetection: Boolean = true,

    /** Enable emulator detection. Inspects [android.os.Build] fields, hardware sensor
     *  availability, and CPU info for emulator signatures. Runs in Kotlin — not gated
     *  by the native library or license feature flags. Always available. */
    val enableEmulatorDetection: Boolean = true,

    /** Enable Frida and debugger detection via native port scanning, /proc/self/maps
     *  inspection, and ptrace checks. Gated by the `runtime_protection` license
     *  feature flag. */
    val enableRuntimeProtection: Boolean = true,

    /** Enable APK and native library integrity verification. Compares APK certificate
     *  and DEX hashes against expected values to detect repackaged or tampered builds.
     *  Pass expected hashes to [com.cybercinch.shield.integrity.IntegrityChecker.detect]
     *  to enrol a specific build; the default empty strings cause each sub-check to
     *  skip (return clean), so dev builds with no enrolled hashes always produce
     *  appTampered = false. Implemented in native code (integrity_checker.cpp). */
    val enableIntegrityCheck: Boolean = true,

    /** Enable TLS certificate pinning for the SDK's own network calls. When true,
     *  pass expected SHA-256 certificate hashes to [CyberCinchShield.enableSslPinning]
     *  before calling [CyberCinchShield.scan]; all SDK requests will be rejected
     *  without them. Disabled by default to simplify initial integration. */
    val enableSslPinning: Boolean = false,

    /** Enable security event telemetry. When false, no [TelemetryDispatcher] is
     *  created, no network calls are made by the telemetry subsystem, and events
     *  detected during [CyberCinchShield.scan] are silently discarded. Local scanning
     *  and license validation continue normally. Use false to honour a user's consent
     *  choice or strict no-background-network requirements. Can also be toggled at
     *  runtime via [CyberCinchShield.setTelemetryConsent]. */
    val enableTelemetry: Boolean = true,

    /** When true, [CyberCinchShield.scan] throws if the server attestation call fails
     *  or returns a high-risk verdict. When false (default), the local scan result is
     *  returned regardless of the server outcome; the server verdict arrives
     *  asynchronously via [CyberCinchShield.onServerVerdict]. Most apps should leave
     *  this false and handle the verdict callback. */
    val failOnAttestationFailure: Boolean = false,

    /** Controls SDK behaviour when the license server is unreachable during
     *  [CyberCinchShield.initialize].
     *
     *  - `true` (default — fail-open): the SDK continues with local-only operation
     *    using [ShieldConfig] flags directly. Scans run, telemetry fires, and the
     *    device stays protected even if the license server is down.
     *    [ScanResult.serverVerified] will be false until connectivity is restored.
     *
     *  - `false` (fail-closed): initialization fails if the license server is
     *    unreachable or rejects the key. [CyberCinchShield.scan] throws until a
     *    successful validation has completed.
     *
     *  **Security tradeoff:** fail-open prioritises availability of device protection;
     *  fail-closed prioritises strict license enforcement at the cost of being
     *  unusable during outages. High-security apps (banking, fintech) that must
     *  guarantee the SDK is operating under a current, valid license should consider
     *  `false`. Most apps should use `true`. */
    val licenseValidationFailOpen: Boolean = true,

    /** SDK log verbosity. [LogLevel.NONE] (default) suppresses all SDK output.
     *  [LogLevel.DEBUG] logs lifecycle events (init, scan, dispatch decisions).
     *  [LogLevel.VERBOSE] adds per-call detail. Always use [LogLevel.NONE] in
     *  release builds; ProGuard strips debug/verbose calls, but explicit NONE is
     *  safer. */
    val logLevel: LogLevel = LogLevel.NONE,

    /** Base URL for the CyberCinch license service. Override for staging or
     *  self-hosted deployments. Must not include a trailing slash. */
    val licenseBaseUrl: String = "https://api.cybercinch.in",

    /** Base URL for the CyberCinch telemetry ingest service. Override for staging
     *  or self-hosted deployments. Must not include a trailing slash. */
    val telemetryBaseUrl: String = "https://api.cybercinch.in",

    /** Base URL for the CyberCinch attestation service. Override for staging or
     *  self-hosted deployments. Must not include a trailing slash. */
    val attestationBaseUrl: String = "https://api.cybercinch.in",

    /** Base URL for the CyberCinch OTA config service. Override for staging or
     *  self-hosted deployments. Must not include a trailing slash. */
    val configBaseUrl: String = "https://api.cybercinch.in",

    /** Controls when queued security events are dispatched to the telemetry backend.
     *
     *  - [TelemetryMode.AUTO_IMMEDIATE] (default): dispatches on a background IO
     *    coroutine immediately after each [CyberCinchShield.scan]. Lowest detection-
     *    to-ingestion latency. Best for apps that scan infrequently (e.g. once per
     *    session) and want real-time backend visibility.
     *
     *  - [TelemetryMode.AUTO_BATCHED]: queues events after each scan and flushes
     *    automatically every [telemetryBatchIntervalMs] milliseconds. Amortises
     *    network activity across multiple scans. Best for apps that scan frequently
     *    (e.g. once per screen) or need to minimise battery/network usage.
     *
     *  - [TelemetryMode.MANUAL]: queues events and never dispatches automatically.
     *    The app must call [CyberCinchShield.flushTelemetry] explicitly — for
     *    example at app foreground, before a sensitive transaction, or on a
     *    WorkManager schedule. Best for apps with strict network budgets or
     *    compliance requirements prohibiting background data upload.
     *
     *  [CyberCinchShield.flushTelemetry] is available as an immediate flush in any
     *  mode. Has no effect when [enableTelemetry] is false. */
    val telemetryMode: TelemetryMode = TelemetryMode.AUTO_IMMEDIATE,

    /** Interval between automatic batch dispatches, in milliseconds. Only relevant
     *  when [telemetryMode] is [TelemetryMode.AUTO_BATCHED]; ignored in other modes.
     *
     *  Default: 60 000 ms (1 minute). Suggested range: 15 000 ms – 300 000 ms
     *  (15 seconds to 5 minutes). Values below 15 000 ms provide little batching
     *  benefit — prefer [TelemetryMode.AUTO_IMMEDIATE] for near-real-time delivery. */
    val telemetryBatchIntervalMs: Long = 60_000,

)
