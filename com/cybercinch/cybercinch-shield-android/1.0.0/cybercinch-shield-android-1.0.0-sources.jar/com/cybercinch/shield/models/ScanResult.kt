package com.cybercinch.shield.models

data class ScanResult(
    val rooted: Boolean,
    val jailbroken: Boolean,
    val emulator: Boolean,
    val runtimeCompromised: Boolean,
    val appTampered: Boolean,
    val riskScore: Int,
    val riskLevel: RiskLevel,
    val events: List<SecurityEvent>,
    val serverVerified: Boolean,
    val scanTimestamp: Long
)
