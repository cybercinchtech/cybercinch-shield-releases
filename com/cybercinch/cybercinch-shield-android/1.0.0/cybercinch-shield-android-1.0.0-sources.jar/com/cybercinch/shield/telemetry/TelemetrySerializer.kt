package com.cybercinch.shield.telemetry

import com.cybercinch.shield.models.SecurityEvent
import org.json.JSONArray
import org.json.JSONObject

class TelemetrySerializer {

    fun serialize(deviceId: String, events: List<SecurityEvent>): String {
        val payload = JSONObject()
        payload.put("device_id", deviceId)
        payload.put("events", JSONArray(events.map { it.toDto() }))
        return payload.toString()
    }

    private fun SecurityEvent.toDto(): JSONObject {
        val dto = JSONObject()
        dto.put("event_id", eventId)
        dto.put("event_type", eventType.name)
        dto.put("risk_score", riskContribution)
        dto.put("detected_at", detectedAt / 1000L) // detectors set ms; server expects Unix seconds
        dto.put("metadata", JSONObject(metadata))
        return dto
    }
}
