package com.cybercinch.shield.core

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri

// Auto-installed at process start via the SDK's own merged manifest — no
// integrator manifest edit or code required (same "no-code init" mechanism
// Firebase/WorkManager use). ContentProvider.onCreate() runs before
// Application.onCreate() and before any Activity.onCreate(), guaranteeing this
// always fires before CyberCinchShield.initialize() ever could.
//
// Deliberately does NOT call CyberCinchCore.initialize() itself — that remains
// the sole, mandatory, API-key-bearing entry point the integrator must call
// explicitly. This only arms a one-shot "run the first scan automatically once
// READY is reached" behavior; see CyberCinchCore.enableAutoFirstScan().
internal class CyberCinchInitProvider : ContentProvider() {

    override fun onCreate(): Boolean {
        CyberCinchCore.enableAutoFirstScan()
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int = 0
}
