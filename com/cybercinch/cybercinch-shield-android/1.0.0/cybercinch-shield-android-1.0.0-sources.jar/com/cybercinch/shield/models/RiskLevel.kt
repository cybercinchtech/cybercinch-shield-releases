package com.cybercinch.shield.models

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }
