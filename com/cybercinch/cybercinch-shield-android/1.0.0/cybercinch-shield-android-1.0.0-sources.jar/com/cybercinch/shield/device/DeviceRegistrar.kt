package com.cybercinch.shield.device

import android.util.Log
import com.cybercinch.shield.network.SslPinningManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

// POST /v1/devices/register (TD-037 PARTs 1/4) — registers this device's
// Keystore public key with license-service once, so subsequent /v1/events
// calls can authenticate via the proof-of-possession JWS path instead of
// the attestation-gated verdict-token path.
//
// A single attempt, deliberately no retry loop: failure here must never
// block initialize() (see CyberCinchCore's call site), and a failed
// registration is retried naturally on the next app launch — only a
// genuine success marks local state as registered, so nothing is lost by
// not retrying aggressively in-process.
internal object DeviceRegistrar {

    private const val REGISTER_PATH = "/v1/devices/register"
    private const val TAG = "DeviceRegistrar"
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun register(
        apiKey: String,
        deviceId: String,
        packageName: String,
        platform: String,
        publicKeyBase64: String,
        baseUrl: String
    ): Boolean = withContext(Dispatchers.IO) {
        val url = baseUrl.trimEnd('/') + REGISTER_PATH
        val bodyJson = JSONObject().apply {
            put("api_key", apiKey)
            put("device_id", deviceId)
            put("package_name", packageName)
            put("platform", platform)
            put("public_key", publicKeyBase64)
        }.toString()

        val request = Request.Builder()
            .url(url)
            .post(bodyJson.toRequestBody(JSON_TYPE))
            .build()

        val client = SslPinningManager.buildSdkClient()
            .newBuilder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    true
                } else {
                    Log.w(TAG, "registration failed: HTTP ${response.code}: ${response.body?.string()?.take(300)}")
                    false
                }
            }
        } catch (e: IOException) {
            Log.w(TAG, "registration failed [${e.javaClass.simpleName}]: ${e.message}")
            false
        }
    }
}
