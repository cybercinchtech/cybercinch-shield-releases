package com.cybercinch.shield.risk

import com.cybercinch.shield.models.ModuleResult
import com.cybercinch.shield.models.RiskLevel
import com.cybercinch.shield.models.SecurityEventType

class RiskEngine {

    fun aggregate(moduleResults: List<ModuleResult>): Pair<Int, RiskLevel> {
        val score = minOf(moduleResults.sumOf { it.riskContribution.coerceAtLeast(0) }, 100)
        val hasIntegrityFailure = moduleResults.any { module ->
            module.events.any { it.eventType == SecurityEventType.INTEGRITY_CHECK_FAILED }
        }
        val level = if (hasIntegrityFailure) RiskLevel.CRITICAL else scoreToLevel(score)
        return Pair(score, level)
    }

    fun scoreToLevel(score: Int): RiskLevel {
        return when {
            score <= 20 -> RiskLevel.LOW
            score <= 50 -> RiskLevel.MEDIUM
            score <= 80 -> RiskLevel.HIGH
            else        -> RiskLevel.CRITICAL
        }
    }
}
