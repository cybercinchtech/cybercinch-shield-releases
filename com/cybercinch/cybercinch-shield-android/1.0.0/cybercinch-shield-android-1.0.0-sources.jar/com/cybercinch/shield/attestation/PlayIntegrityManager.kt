package com.cybercinch.shield.attestation

import android.content.Context
import android.util.Base64
import android.util.Log
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val TAG = "PlayIntegrityManager"

internal data class AttestResult(
    val verdictToken: String,
    val deviceKey: ByteArray
)

// Thrown by postAttest() on a 400 response, carrying the structured
// attestation_status/reason fields attestation-service now provides
// (TD-037 PART 3), rather than only a generic error string. CyberCinchCore
// catches this specifically to capture the detail into local state — see
// CyberCinchCore.lastAttestationStatus/lastAttestationReason.
internal class AttestationFailedException(
    val status: String,
    val reason: String,
    message: String
) : Exception(message)

// Real local-detection snapshot for the /v1/attest request's local_scan field
// (TD-028). Computed once, before attest() is called, by
// CyberCinchCore.runLocalScanForAttestPreflight() — see that function for the
// fallback-on-failure behavior. This type carries only the already-resolved
// values; postAttest() no longer has (or needs) its own fallback logic.
internal data class LocalScanSnapshot(
    val rooted: Boolean,
    val emulator: Boolean,
    val runtimeCompromised: Boolean,
    val appTampered: Boolean,
    val riskScore: Int
)

internal object PlayIntegrityManager {

    // Entry point called from CyberCinchCore.initialize() after license validation
    // succeeds. Fetches a nonce, obtains an integrity token (or falls back to a dev
    // dummy when Play Services is unavailable), then POSTs to /v1/attest and returns
    // the signed verdict token and derived device key from the server response.
    suspend fun attest(
        context: Context,
        sessionToken: String,
        deviceId: String,
        baseUrl: String,
        localScan: LocalScanSnapshot
    ): AttestResult {
        val nonce = fetchNonce(sessionToken, baseUrl)
        Log.d(TAG, "attestation: nonce obtained (${nonce.length} chars)")

        val integrityToken = requestIntegrityToken(context.applicationContext, nonce)
        Log.d(TAG, "attestation: integrity token obtained (${integrityToken.length} chars)")

        return postAttest(
            sessionToken   = sessionToken,
            nonce          = nonce,
            integrityToken = integrityToken,
            deviceId       = deviceId,
            baseUrl        = baseUrl,
            localScan      = localScan
        )
    }

    // GET /v1/attest/nonce — requires the license session JWT as a Bearer token.
    private fun fetchNonce(sessionToken: String, baseUrl: String): String {
        val conn = URL("$baseUrl/v1/attest/nonce").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.setRequestProperty("Authorization", "Bearer $sessionToken")
            conn.connectTimeout = 10_000
            conn.readTimeout    = 10_000
            val code = conn.responseCode
            if (code != 200) {
                val body = conn.errorStream?.bufferedReader()?.readText() ?: "(no body)"
                error("GET /v1/attest/nonce returned HTTP $code: $body")
            }
            return JSONObject(conn.inputStream.bufferedReader().readText()).getString("nonce")
        } finally {
            conn.disconnect()
        }
    }

    // Calls Google Play Integrity API. On emulators or devices without Play Services
    // the Task fails immediately; the exception is caught and a dev fallback token
    // is returned so the rest of the attestation flow can still be exercised.
    private suspend fun requestIntegrityToken(context: Context, nonce: String): String {
        return try {
            val manager = IntegrityManagerFactory.create(context)
            val request = IntegrityTokenRequest.builder()
                .setNonce(nonce)
                .build()
            suspendCancellableCoroutine { cont ->
                manager.requestIntegrityToken(request)
                    .addOnSuccessListener { cont.resume(it.token()) }
                    .addOnFailureListener { cont.resumeWithException(it) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Play Integrity unavailable [${e.javaClass.simpleName}]: ${e.message} — using dev fallback token")
            "dev-dummy-token"
        }
    }

    // POST /v1/attest — sends the integrity token and nonce, gets back a verdict
    // token and a base64-encoded 32-byte device key (HKDF output from the server).
    // local_scan carries the real pre-flight detection snapshot (TD-028) — computed
    // by CyberCinchCore.runLocalScanForAttestPreflight() before attest() was called.
    private fun postAttest(
        sessionToken: String,
        nonce: String,
        integrityToken: String,
        deviceId: String,
        baseUrl: String,
        localScan: LocalScanSnapshot
    ): AttestResult {
        val body = JSONObject().apply {
            put("platform", "android")
            put("attestation_token", integrityToken)
            put("nonce", nonce)
            put("device_id", deviceId)
            put("local_scan", JSONObject().apply {
                put("rooted", localScan.rooted)
                put("emulator", localScan.emulator)
                put("runtime_compromised", localScan.runtimeCompromised)
                put("app_tampered", localScan.appTampered)
                put("local_risk_score", localScan.riskScore)
            })
        }.toString()

        Log.d(TAG, "attestation: POST /v1/attest local_scan=$localScan")

        val conn = URL("$baseUrl/v1/attest").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Authorization", "Bearer $sessionToken")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 15_000
            conn.readTimeout    = 15_000
            conn.doOutput       = true
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }

            val code = conn.responseCode
            if (code != 200) {
                val errBody = conn.errorStream?.bufferedReader()?.readText() ?: "(no body)"
                // Parse the structured fields PART 3 added to
                // AttestFailedResponse; fall back to a generic exception if
                // they're absent (defensive — an older backend without the
                // new field must not crash the parse) rather than a
                // different failure shape either way.
                val (status, reason) = try {
                    val errJson = JSONObject(errBody)
                    errJson.optString("attestation_status", "ATTESTATION_UNAVAILABLE") to
                        errJson.optString("reason", "HTTP $code")
                } catch (e: Exception) {
                    "ATTESTATION_UNAVAILABLE" to "HTTP $code: $errBody"
                }
                throw AttestationFailedException(
                    status = status,
                    reason = reason,
                    message = "POST /v1/attest returned HTTP $code: $errBody"
                )
            }

            val resp = JSONObject(conn.inputStream.bufferedReader().readText())
            val verdictToken = resp.getString("verdict_token")
            val deviceKey = Base64.decode(resp.getString("device_key"), Base64.DEFAULT)

            Log.d(TAG, "attestation: POST /v1/attest succeeded, risk_level=${resp.getString("server_risk_level")}")
            return AttestResult(verdictToken = verdictToken, deviceKey = deviceKey)
        } finally {
            conn.disconnect()
        }
    }
}
