package com.cybercinch.shield.root

import com.cybercinch.shield.models.ModuleResult
import com.cybercinch.shield.models.SecurityEvent
import com.cybercinch.shield.models.SecurityEventType
import java.util.UUID

class RootDetector {

    private external fun nativeCheckRoot(): IntArray

    // Converts raw native result [isRooted, signalsBitmask] into ModuleResult.
    // Each bit maps to a distinct SecurityEventType with its own risk weight.
    fun detect(): ModuleResult {
        val startMs = System.currentTimeMillis()
        val raw = nativeCheckRoot()
        val bitmask  = raw[1]
        val now = System.currentTimeMillis()

        // raw[0] is legacy/non-authoritative (see root_detector.cpp) — isRooted is
        // derived here from the bitmask. SIG_VERIFIED_BOOT is deliberately excluded as a
        // conjunct: confirmed on Pixel 9a (2026-07-04) that an installed Magisk module
        // (playintegrityfix/service.sh) actively resets ro.boot.verifiedbootstate to
        // "green" once sys.boot_completed=1, so it cannot reliably gate root detection.
        // The signal still fires its own event for telemetry visibility (0 risk weight).
        val legacyHardFlag = bitmask and (SIG_ROOT_BINARY or SIG_ZYGISK_MAPS or SIG_SYSTEM_RW or SIG_TEST_KEYS) != 0
        val mountAnomaly    = bitmask and (SIG_MOUNTINFO_TMPFS or SIG_MOUNTS_TMPFS) != 0
        val isRooted = legacyHardFlag || mountAnomaly

        val events = buildList {
            if (bitmask and SIG_ROOT_BINARY != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 60,
                detectedAt       = now,
                metadata         = mapOf("signal" to "root_binary")
            ))
            if (bitmask and SIG_ZYGISK_MAPS != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ZYGISK_DETECTED,
                riskContribution = 70,
                detectedAt       = now,
                metadata         = mapOf("signal" to "proc_maps_zygisk")
            ))
            if (bitmask and SIG_SYSTEM_RW != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 50,
                detectedAt       = now,
                metadata         = mapOf("signal" to "system_partition_rw")
            ))
            if (bitmask and SIG_TEST_KEYS != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 30,
                detectedAt       = now,
                metadata         = mapOf("signal" to "test_keys")
            ))
            if (bitmask and SIG_VERIFIED_BOOT != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 0,
                detectedAt       = now,
                metadata         = mapOf("signal" to "verified_boot_orange_yellow")
            ))
            if (bitmask and SIG_MOUNTINFO_TMPFS != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 60,
                detectedAt       = now,
                metadata         = mapOf("signal" to "mountinfo_tmpfs_over_system")
            ))
            if (bitmask and SIG_MOUNTS_TMPFS != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 50,
                detectedAt       = now,
                metadata         = mapOf("signal" to "mounts_tmpfs_over_system")
            ))
            if (bitmask and SIG_SELINUX_ANOMALY != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 40,
                detectedAt       = now,
                metadata         = mapOf("signal" to "selinux_enforce_readable_or_missing")
            ))
            if (bitmask and SIG_PROCNET_UNIX_ANOMALY != 0) add(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.ROOT_DETECTED,
                riskContribution = 35,
                detectedAt       = now,
                metadata         = mapOf("signal" to "procnet_unix_readable")
            ))
        }

        return ModuleResult(
            moduleName       = MODULE_NAME,
            passed           = !isRooted,
            riskContribution = events.sumOf { it.riskContribution }.coerceAtMost(100),
            events           = events,
            durationMs       = System.currentTimeMillis() - startMs
        )
    }

    companion object {
        private const val MODULE_NAME    = "RootDetector"
        private const val SIG_ROOT_BINARY     = 1 shl 0
        private const val SIG_ZYGISK_MAPS     = 1 shl 1
        private const val SIG_SYSTEM_RW       = 1 shl 2
        private const val SIG_TEST_KEYS       = 1 shl 3
        private const val SIG_VERIFIED_BOOT   = 1 shl 4
        private const val SIG_MOUNTINFO_TMPFS = 1 shl 5
        private const val SIG_MOUNTS_TMPFS    = 1 shl 6
        // bit 7 reserved for SIG_ZYGISK_TIMING — not implemented yet, see TD-012
        private const val SIG_SELINUX_ANOMALY = 1 shl 8
        private const val SIG_PROCNET_UNIX_ANOMALY = 1 shl 9

        init { System.loadLibrary("cybercinch_shield") }
    }
}
