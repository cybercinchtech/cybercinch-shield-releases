package com.cybercinch.shield.models

data class ModuleResult(
    val moduleName: String,
    val passed: Boolean,
    val riskContribution: Int,
    val events: List<SecurityEvent>,
    val durationMs: Long
)
