package com.cybercinch.shield.device

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature

// Device-held asymmetric keypair for proof-of-possession telemetry
// authentication (TD-037). Generated once via Android Keystore —
// hardware-backed (TEE) where available, software fallback otherwise,
// exactly the same behavior as CyberCinchCore's existing AES key
// (deliberately no setIsStrongBoxBacked(true) call, matching that
// existing pattern precisely and avoiding a StrongBoxUnavailableException
// failure mode the existing key doesn't have either). Critically, key
// generation itself does not depend on Play Integrity, Play Store, or
// root status, and succeeds unconditionally — see TD-037's "architectural
// inversion" finding for why that property is the entire point.
//
// NIST P-256 (KeyProperties EC, 256-bit key size) + SHA-256 — matches JWS
// ES256 exactly, which telemetry-service's verifyDeviceJWS requires
// explicitly (jwt.WithValidMethods([]string{"ES256"})).
internal object DeviceSigningKey {

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "cc_shield_device_sign_v1"

    // P-256's R and S are each at most 32 bytes — JWS ES256 (RFC 7518 §3.4)
    // requires each fixed at exactly this length in the raw signature.
    private const val EC_COMPONENT_SIZE = 32

    // Idempotent via Keystore's own alias check — safe to call on every
    // initialize(); only generates a key the first time it's ever called
    // on this device.
    fun ensureKeyPair() {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        if (ks.containsAlias(KEY_ALIAS)) return
        val keyGen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, KEYSTORE_PROVIDER)
        keyGen.initialize(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setKeySize(256) // NIST P-256 on Android Keystore's EC algorithm — required for ES256
                .build()
        )
        keyGen.generateKeyPair()
    }

    fun hasKeyPair(): Boolean {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        return ks.containsAlias(KEY_ALIAS)
    }

    // Base64-encoded X.509 SubjectPublicKeyInfo DER — the exact format
    // telemetry-service's x509.ParsePKIXPublicKey expects server-side, and
    // what license-service's POST /v1/devices/register stores verbatim.
    fun publicKeyBase64(): String? {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val cert = ks.getCertificate(KEY_ALIAS) ?: return null
        return Base64.encodeToString(cert.publicKey.encoded, Base64.NO_WRAP)
    }

    private fun privateKeyEntry(): KeyStore.PrivateKeyEntry? {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        return ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry
    }

    // Builds and signs a compact JWS (header.payload.signature, base64url,
    // no padding) matching telemetry-service's deviceJWSClaims field names
    // exactly: api_key_id, device_id, pkg, nonce, body_hash, plus standard
    // iat/exp. Returns null if the Keystore key is unavailable — callers
    // must treat that as "fall back to the verdict-token path", never as a
    // hard failure (this is the dual-auth transition working as designed).
    fun signJWS(apiKeyId: String, deviceId: String, pkg: String, nonce: String, bodyHash: String): String? {
        val entry = privateKeyEntry() ?: return null

        val nowSec = System.currentTimeMillis() / 1000L
        val header = JSONObject().apply {
            put("alg", "ES256")
            put("typ", "JWT")
        }.toString()
        val payload = JSONObject().apply {
            put("api_key_id", apiKeyId)
            put("device_id", deviceId)
            put("pkg", pkg)
            put("nonce", nonce)
            put("body_hash", bodyHash)
            put("iat", nowSec)
            put("exp", nowSec + 300) // 5-minute validity — matches the HMAC path's own timestamp window
        }.toString()

        val signingInput = "${b64url(header)}.${b64url(payload)}"

        // Signature.getInstance("SHA256withECDSA") produces an ASN.1
        // DER-encoded SEQUENCE(INTEGER r, INTEGER s) — JWS ES256 requires the
        // raw, fixed-length R||S concatenation instead (RFC 7518 §3.4).
        // derToJwsSignature() below does that conversion; skipping it is a
        // common, silent JWS/ES256 interop bug (the Go backend's
        // jwt.SigningMethodECDSA verifier expects the raw form and would
        // reject a DER-formatted signature outright).
        val derSignature = Signature.getInstance("SHA256withECDSA").apply {
            initSign(entry.privateKey)
            update(signingInput.toByteArray(Charsets.UTF_8))
        }.sign()

        val jwsSignature = derToJwsSignature(derSignature, EC_COMPONENT_SIZE)

        return "$signingInput.${b64url(jwsSignature)}"
    }

    private fun b64url(data: String): String =
        b64url(data.toByteArray(Charsets.UTF_8))

    private fun b64url(data: ByteArray): String =
        Base64.encodeToString(data, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)

    // Converts a JCA ASN.1 DER ECDSA signature to JWS's fixed-length raw
    // R||S format (RFC 7518 §3.4). componentSize is 32 for P-256 — each of
    // R and S is left-zero-padded (or truncated, for the rare case DER's
    // sign-avoidance byte survives stripping) to exactly that length.
    private fun derToJwsSignature(der: ByteArray, componentSize: Int): ByteArray {
        var offset = 2 // skip SEQUENCE tag (0x30) + the length byte itself
        if ((der[1].toInt() and 0x80) != 0) {
            // Long-form ASN.1 length encoding — never actually occurs for a
            // P-256 signature (total content is always < 128 bytes), but
            // handled defensively rather than assumed away.
            offset += der[1].toInt() and 0x7F
        }

        fun readInt(): ByteArray {
            require(der[offset] == 0x02.toByte()) { "derToJwsSignature: expected INTEGER tag" }
            offset++
            val len = der[offset].toInt() and 0xFF
            offset++
            var bytes = der.copyOfRange(offset, offset + len)
            offset += len
            // Strip a leading 0x00 sign-avoidance byte ASN.1 INTEGER encoding
            // adds when the high bit of the first real byte would otherwise
            // make the value read as negative.
            if (bytes.size > 1 && bytes[0] == 0x00.toByte() && (bytes[1].toInt() and 0x80) != 0) {
                bytes = bytes.copyOfRange(1, bytes.size)
            }
            return bytes
        }

        val r = readInt()
        val s = readInt()

        fun fixedLength(component: ByteArray): ByteArray {
            val out = ByteArray(componentSize)
            val copyLen = minOf(component.size, componentSize)
            System.arraycopy(component, component.size - copyLen, out, componentSize - copyLen, copyLen)
            return out
        }

        return fixedLength(r) + fixedLength(s)
    }
}
