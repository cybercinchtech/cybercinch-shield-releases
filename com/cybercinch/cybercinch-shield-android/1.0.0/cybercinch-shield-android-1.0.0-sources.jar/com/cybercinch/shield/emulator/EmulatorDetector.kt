package com.cybercinch.shield.emulator

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.telephony.TelephonyManager
import com.cybercinch.shield.models.ModuleResult
import com.cybercinch.shield.models.SecurityEvent
import com.cybercinch.shield.models.SecurityEventType
import com.cybercinch.shield.runtime.RuntimeProtector
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.util.UUID

// Emulator detection is explicitly allowed in Kotlin (lower risk — environment
// signal only, not a trust gate). See android-sdk/CLAUDE.md "emulator/" section.
class EmulatorDetector {

    // emulator_detector.cpp: techniques 1, 3, 4
    // Returns int[2] = { isEmulator(0/1), signalsBitmask }
    private external fun nativeCheckEmulator(): IntArray

    fun detect(context: Context): ModuleResult {
        val startMs = System.currentTimeMillis()

        // Native signals — isEmulator is decided from typed bitmask values before
        // the display metadata map is built, so a key rename can never silently
        // promote a partial signal to a hard flag.
        val nativeResult   = nativeCheckEmulator()
        val nativeBitmask  = nativeResult[1]
        val nativeHardFlag = (nativeBitmask and (SIG_EMU_DRIVER or SIG_EMU_SYSPROP)) != 0

        // Technique 2: libhoudini / libndk_translation maps scan — implemented in
        // frida_detector.cpp for scan_maps() reuse; exposed via RuntimeProtector.
        val houdini = RuntimeProtector.checkTranslationMaps()

        // Kotlin-layer signals (Build class and environment checks)
        val kotlinSignals = mapOf(
            "build_fingerprint"  to checkBuildFingerprint(),
            "build_model"        to checkBuildModel(),
            "build_hardware"     to checkBuildHardware(),
            "build_manufacturer" to checkBuildManufacturer(),
            "telephony_imei"     to checkTelephonyImei(context),
            "sensor_missing"     to checkSensorsAbsent(context),
            "cpuinfo_goldfish"   to checkCpuInfoGoldfish(),
        )
        val kotlinHardFlag = kotlinSignals.any { it.value }

        val isEmulator = kotlinHardFlag || nativeHardFlag || (houdini != 0)
        val now = System.currentTimeMillis()

        // Signals metadata map — for telemetry display only; not used for flag logic
        val signalsMeta = kotlinSignals.toMutableMap()
        if (nativeBitmask and SIG_EMU_DRIVER  != 0) signalsMeta["native_driver_path"]  = true
        if (nativeBitmask and SIG_EMU_SYSPROP != 0) signalsMeta["native_sysprop"]      = true
        if (nativeBitmask and SIG_EMU_NETWORK != 0) signalsMeta["native_network"]      = true
        if (houdini != 0)                            signalsMeta["native_houdini_maps"] = true

        val events = if (isEmulator) {
            listOf(SecurityEvent(
                eventId          = UUID.randomUUID().toString(),
                eventType        = SecurityEventType.EMULATOR_DETECTED,
                riskContribution = 50,
                detectedAt       = now,
                metadata         = mapOf("signals" to signalsMeta.filter { it.value }.keys.joinToString(","))
            ))
        } else emptyList()

        return ModuleResult(
            moduleName       = MODULE_NAME,
            passed           = !isEmulator,
            riskContribution = if (isEmulator) 50 else 0,
            events           = events,
            durationMs       = System.currentTimeMillis() - startMs
        )
    }

    private fun checkBuildFingerprint(): Boolean {
        val fp = Build.FINGERPRINT.lowercase()
        return fp.startsWith("generic") || fp.startsWith("unknown") ||
               fp.contains("emulator")  || fp.contains("sdk_gphone") ||
               fp == "robolectric"
    }

    private fun checkBuildModel(): Boolean {
        val model   = Build.MODEL.lowercase()
        val product = Build.PRODUCT.lowercase()
        return model.contains("emulator") ||
               model == "android sdk built for x86" ||
               model == "android sdk built for arm64" ||
               product.startsWith("sdk") ||
               product.contains("emulator") ||
               product == "google_sdk"
    }

    private fun checkBuildHardware(): Boolean {
        val hw = Build.HARDWARE.lowercase()
        return hw == "goldfish" || hw == "ranchu" || hw.contains("vbox")
    }

    private fun checkBuildManufacturer(): Boolean {
        val mfr   = Build.MANUFACTURER.lowercase()
        val brand = Build.BRAND.lowercase()
        return mfr.contains("genymotion") || (mfr == "google" && brand == "android")
    }

    // Requires READ_PHONE_STATE; restricted to privileged apps on API 29+.
    // Returns false on SecurityException rather than false-positiving.
    private fun checkTelephonyImei(context: Context): Boolean {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE)
                as? TelephonyManager ?: return false
            @Suppress("MissingPermission")
            val imei = tm.imei ?: return false
            imei.all { it == '0' }
        } catch (_: SecurityException) { false }
          catch (_: Exception)         { false }
    }

    // Emulators typically lack both an accelerometer and gyroscope.
    private fun checkSensorsAbsent(context: Context): Boolean {
        val sm = context.getSystemService(Context.SENSOR_SERVICE)
            as? SensorManager ?: return false
        val noAccel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null
        val noGyro  = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) == null
        return noAccel && noGyro
    }

    // CLAUDE.md specifies "via native call" but emulator detection is explicitly
    // allowed in Kotlin. We read directly rather than adding an out-of-scope JNI
    // function. An unreadable file is treated as "not goldfish".
    private fun checkCpuInfoGoldfish(): Boolean {
        return try {
            BufferedReader(FileReader(File("/proc/cpuinfo"))).use { reader ->
                reader.lineSequence().any { line ->
                    line.contains("goldfish", ignoreCase = true) ||
                    line.contains("ranchu",   ignoreCase = true)
                }
            }
        } catch (_: Exception) { false }
    }

    companion object {
        private const val MODULE_NAME    = "EmulatorDetector"
        private const val SIG_EMU_DRIVER  = 1 shl 0
        private const val SIG_EMU_SYSPROP = 1 shl 1
        private const val SIG_EMU_NETWORK = 1 shl 2

        init { System.loadLibrary("cybercinch_shield") }
    }
}
