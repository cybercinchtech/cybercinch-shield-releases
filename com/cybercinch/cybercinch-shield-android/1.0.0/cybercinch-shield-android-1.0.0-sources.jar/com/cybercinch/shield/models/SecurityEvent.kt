package com.cybercinch.shield.models

enum class SecurityEventType {
    ROOT_DETECTED,
    ZYGISK_DETECTED,
    EMULATOR_DETECTED,
    FRIDA_DETECTED,
    DEBUGGER_ATTACHED,
    APP_TAMPERING_DETECTED,
    SSL_PINNING_BYPASS,
    JAILBREAK_DETECTED,
    HOOK_FRAMEWORK_DETECTED,
    INTEGRITY_CHECK_FAILED,
    ATTESTATION_UNAVAILABLE,

    // Not a security signal — an SDK-side client crash/exception report.
    // risk_score is always 0 when this type is emitted (see
    // CyberCinchCore.reportError): daily_risk_summary buckets by risk_score
    // into CRITICAL/HIGH/MEDIUM/LOW, and a crash is not a compromise
    // indicator, so scoring it nonzero would distort that view. Do not
    // "fix" this into a nonzero score.
    CLIENT_ERROR_REPORTED
}

data class SecurityEvent(
    val eventId: String,
    val eventType: SecurityEventType,
    val riskContribution: Int,
    val detectedAt: Long,
    val metadata: Map<String, String> = emptyMap()
)
